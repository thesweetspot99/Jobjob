import React, { useState } from 'react';

export default function JobApplicationForm({ jobId, user }) {
  const [coverLetter, setCoverLetter] = useState('');
  const [resume, setResume] = useState(null);
  const [status, setStatus] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append('jobId', jobId);
    formData.append('userId', user.id);
    formData.append('name', user.name);
    formData.append('email', user.email);
    formData.append('phone', user.phone);
    formData.append('coverLetter', coverLetter);
    if (resume) formData.append('resume', resume);

    try {
      const response = await fetch('/api/apply', {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        setStatus('Application submitted successfully!');
      } else {
        setStatus('Failed to submit application.');
      }
    } catch (error) {
      console.error('Error:', error);
      setStatus('An error occurred.');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="p-4 space-y-4 bg-white shadow-md rounded-xl">
      <h2 className="text-xl font-bold">Apply for this Job</h2>
      <textarea
        className="w-full p-2 border rounded"
        placeholder="Write your cover letter here..."
        value={coverLetter}
        onChange={(e) => setCoverLetter(e.target.value)}
        rows={5}
      />
      <input
        type="file"
        onChange={(e) => setResume(e.target.files[0])}
        className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
      />
      <button
        type="submit"
        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
      >
        Submit Application
      </button>
      {status && <p className="text-sm text-gray-700">{status}</p>}
    </form>
  );
}
