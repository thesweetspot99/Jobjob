import { initializeApp, getApps } from 'firebase/app';
import { getFirestore, collection, addDoc } from 'firebase/firestore';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import nextConnect from 'next-connect';
import multer from 'multer';

const firebaseConfig = {
  apiKey: process.env.FIREBASE_API_KEY,
  authDomain: process.env.FIREBASE_AUTH_DOMAIN,
  projectId: process.env.FIREBASE_PROJECT_ID,
  storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.FIREBASE_APP_ID,
};

if (!getApps().length) initializeApp(firebaseConfig);
const db = getFirestore();
const storage = getStorage();

const upload = multer({ storage: multer.memoryStorage() });
const apiRoute = nextConnect({
  onError(error, req, res) {
    res.status(501).json({ error: `Something went wrong: ${error.message}` });
  },
});

apiRoute.use(upload.single('resume'));

apiRoute.post(async (req, res) => {
  const { jobId, userId, name, email, phone, coverLetter } = req.body;
  let resumeURL = '';

  if (req.file) {
    const storageRef = ref(storage, `resumes/${Date.now()}-${req.file.originalname}`);
    const snapshot = await uploadBytes(storageRef, req.file.buffer);
    resumeURL = await getDownloadURL(snapshot.ref);
  }

  await addDoc(collection(db, 'applications'), {
    jobId,
    userId,
    name,
    email,
    phone,
    coverLetter,
    resumeURL,
    submittedAt: new Date()
  });

  res.status(200).json({ message: 'Application submitted successfully.' });
});

export default apiRoute;

export const config = {
  api: {
    bodyParser: false,
  },
};
